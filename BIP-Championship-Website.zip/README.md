# BIP Championship Website

A free, static website designed for GitHub Pages.

## Your free URL

GitHub Pages uses the account name in the URL. To obtain:

`https://bipchampionship.github.io`

create a GitHub account/organization named **bipchampionship** and a public repository named:

`bipchampionship.github.io`

Upload all files from this folder to the root of that repository.

## Edit the website

The easiest content file is:

`assets/data/site-data.json`

You can edit it directly in GitHub by opening the file and clicking the pencil icon.

- Add a tournament under `tournaments`
- Add or update players under `players`
- Add records under `records`
- Add gallery images under `gallery`

For photos, upload image files into `assets/images/gallery/` and enter the relative path in the data file, for example:

`assets/images/gallery/2025-team-photo.jpg`

## Publish

1. Create a GitHub account or organization named `bipchampionship`.
2. Create a public repository called `bipchampionship.github.io`.
3. Upload the contents of this folder.
4. In repository Settings → Pages, select **Deploy from a branch**, branch `main`, folder `/root`.
5. Your website will appear at `https://bipchampionship.github.io`.

## Important limitation

GitHub Pages does not provide a private visual admin dashboard or password login. Editing is done through your private GitHub account. This is still fully editable and free. A true login-based CMS generally requires an additional service.
